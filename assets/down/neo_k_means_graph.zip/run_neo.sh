#!/bin/bash
./neo -a 0.2000 -b 0.0000 -s 0 ./data/karate-metis-graph 2
