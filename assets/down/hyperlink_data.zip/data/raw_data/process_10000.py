f_o = open('../web_data/web_10000.txt','w')
f_d = open('web_10000_domain.txt','w')
f_a = open('web_10000_action.txt','w')

id2dom = {}

f_i = open('raw_10000.txt','r')
while True:
	line = f_i.readline()
	if not line: break
	term = line.split('	')
	link_type = term[0]
	src_url_id = int(term[4]) 
	dst_url_id = int(term[11]) 
	src_dom_id = int(term[6])
	dst_dom_id = int(term[13])
	f_o.write(str(src_url_id) + ',' + str(dst_url_id) + ',')
	if link_type == 'n':
		f_o.write('n\n')
	elif link_type  == 's':
		f_o.write('s\n')
	else:
		f_o.write('a\n')
	id2dom[src_url_id] = src_dom_id
	id2dom[dst_url_id] = dst_dom_id
	anchor = term[7].lower()
	if ('e-mail' in anchor) or ('edit' in anchor) or ('share' in anchor) or ('vote' in anchor):
		f_a.write(str(src_url_id) + '	' + str(dst_url_id) + '\n')
	if link_type == 'e':
		print(anchor)
for u, d in id2dom.items():
	f_d.write(str(u) + '	' + str(d) + '\n')

f_a.close()
f_d.close()
f_i.close()
f_o.close()
