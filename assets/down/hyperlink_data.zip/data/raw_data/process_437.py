f_o = open('../web_data/web_437.txt','w')
f_d = open('web_437_domain.txt','w')

id2dom = {}

f_i = open('raw_437.txt','r')
while True:
	line = f_i.readline()
	if not line: break
	term = line.split('	')
	link_type = term[0]
	src_url_id = int(term[1])
	dst_url_id = int(term[4])
	src_dom_id = int(term[2])
	dst_dom_id = int(term[5])
	f_o.write(str(src_url_id) + ',' + str(dst_url_id) + ',')
	if link_type == 'navi':
		f_o.write('n\n')
	elif link_type  == 'sugg':
		f_o.write('s\n')
	else:
		f_o.write('a\n')
	id2dom[src_url_id] = src_dom_id
	id2dom[dst_url_id] = dst_dom_id

for u, d in id2dom.items():
	f_d.write(str(u) + '	' + str(d) + '\n')

f_d.close()
f_i.close()
f_o.close()
