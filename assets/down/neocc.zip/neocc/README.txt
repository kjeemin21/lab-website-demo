* Please acknowledge the use of the code with a citation.
"Non-Exhaustive, Overlapping Co-Clustering", Proceedings of the 26th ACM Conference on Information and Knowledge Management (CIKM), pages 2367–2370, November 2017.

* Please also read the arXiv paper, "Non-Exhaustive, Overlapping Co-Clustering: An Extended Analysis" for more details.

* To use NEO-CC-M objective, 
[U,V,J] = neo_cc2(X,k,l,alpha_r,beta_r,alpha_c,beta_c,initU,initV,'v1');

* To use, NEO-CC-RCM objective,
[U,V,J] = neo_cc2(X,k,l,alpha_r,beta_r,alpha_c,beta_c,initU,initV,'v2');
